; minimOS 0.4.1a1 zero-page system variables
; (c) 2012-2014 Carlos J. Santisteban
; last modified 2014.10.10

.zero

; user space
* = 0
reserved	.word	0	; reserved for 6510, free for user otherwise
z_used		.byt	0	; user-reserved space in ZP
user:					; user context starts here, $03...$DF

; reserved for kernel functions
* = $E0					; new address 130603, hope it stays forever!
sysvar		.dsb	12	; variables for kernel functions @ $E0

; kernel parameters
z10L:
z10W:
z10:	.dsb	4		; up to 4 bytes, including older z10L and z10W @ $EC
z6L:
z6W:
z6:		.dsb	4		; all @ $F0
z2L:
z2W:
z2:		.dsb	4		; all @ $F4

; reserved for system use
sysptr		.word	0		; ZP pointer for interrupts only @ $F8
systmp		.byt	0		; temporary storage for interrupts only @ $FA
sys_sp		.byt	0		; stack pointer for context switch @ $FB (wtf?)
signature	.asc	"mOS!"	; process' short name @ $FC (put on stack "bottom"?)
