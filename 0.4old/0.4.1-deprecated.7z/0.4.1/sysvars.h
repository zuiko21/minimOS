; minimOS 0.4.1a1 System Variables
; (c) 2012-2013 Carlos J. Santisteban
; last modified 2013.06.04

.bss

#ifdef MTE
* = $0030	; for 128-byte RAM!
#else 
* = $0200	; most systems with at least 1 kiB SRAM
#endif

irqvec		.word	0	; ISR vector
user_nmi	.word	0   ; user-NMI vector (begins with 'UNj*')
irq_freq	.word	0   ; IRQs per second
ticks		.dsb	5   ; (irq_freq)-interrupts, then approximate uptime in seconds (3 bytes)
himem		.byt	64	; number of SRAM pages
ptr_page	.byt	3	; first allocatable RAM page! KLUDGE
default_out	.byt	0
default_in	.byt	0
old_t1		.word	0	; keep old T1 latch value for FG

;driver-specific system variables come after this one, in main source
