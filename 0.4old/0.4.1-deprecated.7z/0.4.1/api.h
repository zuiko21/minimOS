; minimOS 0.4.1a1 API
; (c) 2012-2013 Carlos J. Santisteban
; last modified 2013.06.03

; include here the old 'io_dev.h' (plus some from 'macros.h')

; VIA 65(C)22 registers
; Base address, machine dependant
#ifdef	SDd
VIA = $6FF0		; SDd, Chihuahua, Chihuahua PLUS
#else
VIA	= $DFF0		; most machines so far
#endif

; Offsets from base address (add when using)
IORB	= $0
IORA	= $1
DDRB	= $2
DDRA	= $3
T1CL	= $4
T1CH	= $5
T1LL	= $6
T1LH	= $7
T2CL	= $8
T2CH	= $9
SR		= $A
ACR		= $B
PCR		= $C
IFR		= $D
IER		= $E
NHRA	= $F	; IRA/ORA without handshake

; Driver table offsets
D_INIT	=  $0	; device reset
D_POLL	=  $2	; periodic interrupt task
D_REQ	=  $4	; asynchronous interrupt request
D_CIN	=  $6	; character input
D_COUT	=  $8	; character output
D_SEC	=  $A	; 1-second interrupt
D_SIN	=  $C	; block input
D_SOUT	=  $E	; block output
D_BYE	= $10	; shutdown procedure
D_AUTH	= $12	; authorization code
D_ID	= $13	; driver ID
D_MEM	= $14	; NEW, required space (if relocatable)

; kernel function codes for system call
COUT		=   0
CIN			=   2
MALLOC		=   4
FREE		=   6
OPEN_W		=   8
CLOSE_W		=  10
FREE_W		=  12
UPTIME		=  14	; no longer_hid_push!
B_FORK		=  16
B_EXEC		=  18
LOAD_LINK	=  20
SU_POKE		=  22	; access protected memory or I/O
SU_PEEK		=  24
STRING		=  26
SU_SEI		=  28	; disable interrupts
SU_CLI		=  30	; enable interrupts, not really needed on 65xx
SET_FG		=  32
FIFO_SET	=  34	; NEW in 0.4.1
FIFO_IN		=  36	; special ABI, intended for drivers
FIFO_OUT	=  38

; error codes
OK		=   0	; not needed on 65xx, CLC instead
UNAVAIL	=   1	; unavailable on this version
TIMEOUT	=   2	; try later
FULL	=   3	; not enough memory, try less
N_FOUND	=   4	; try another
NO_RSRC	=   5	; no windows, try a different way
EMPTY	=   6	; put some and retry
INVALID	=   7	; invalid argument
BUSY	=   8	; can't use it now, free it or wait

; these are temporary, thus no uppercase yet
; to be determined... from D_ID?
#define led_dev		252
#define lcd_dev		210
#define acia_dev	236
#define ss22_dev	250
#define ascii_lcd	241

; more temporary IDs

; lcd-4-bit @ascii = 240
; acia 2651 = 237
; VIA PA parallel port = 243
; VDU @ VIAport = 242
; (d)uart-16c550-1 = 232 hehehe
; duart-16c552-0 (or 2) = 224
; rtc 146818 (pseudo-driver?) = 208
; duart 2681-1 = 235 (or 227)
; duart 2681-2 = 227 (or 235)
