; minimOS 0.4.1a1 MACRO definitions
; (c) 2012-2014 Carlos J. Santisteban
; last modified 2014-10-10, was 2013.06.04

#define		_EXIT_OK	CLC: RTS
#define		_ERR(a)		LDY #a: SEC: RTS
#define		_KERNEL(a)	LDX #a: JSR k_call

#define		_SEI		SEI
; otherwise _KERNEL(SU_SEI)
#define		_CLI		CLI
; otherwise _KERNEL(SU_CLI) not really needed on 65xx 

#ifdef	NMOS
#define		_JMPX(a)	LDA a, X: STA sysvar: LDA a+1, X: STA sysvar+1: JMP (sysvar)
#define		_PHX		TXA: PHA
#define		_PHY		TYA: PHA
#define		_PLX		PHA: TAX
#define		_PLY		PHA: TAY
#define		_STAX(a)	LDX #0: STA (a, X)
#define		_LDAX(a)	LDX #0: LDA (a, X)
#define		_INC		CLC: ADC #1
#define		_DEC		SEC: SBC #1
#define		_BRA		CLV:BVC
#define		_STZX		LDX #0: STX
#define		_STZY		LDY #0: STY
#define		_STZA		LDA #0: STA
#else
#define		_JMPX(a)	JMP (a, X)
#define		_PHX		PHX
#define		_PHY		PHY
#define		_PLX		PLX
#define		_PLY		PLY
#define		_STAX(a)	STA (a)
#define		_LDAX(a)	LDA (a)
#define		_INC		INC
#define		_DEC		DEC
#define		_BRA		BRA
#define		_STZX		STZ
#define		_STZY		STZ
#define		_STZA		STZ
#endif

; highest SRAM page, just in case of mirroring/bus error -- or number of pages?
; MTE needs mirroring for the stack, but it has just 128 bytes!
; SDd has 2 kiB max
; 63 pages (16 kiB) is the general case, OK for SDx too, even without hAck14!
#ifdef	MTE
#define		_SRAM	1		
#else
#ifdef	SDd
#define		_SRAM	7
#else
#define		_SRAM	63
#endif
#endif

; initial stack pointer, MTE has 128-byte RAM!
#ifdef	MTE
#define		_SP		$60
#else
#define		_SP		$FF
#endif
